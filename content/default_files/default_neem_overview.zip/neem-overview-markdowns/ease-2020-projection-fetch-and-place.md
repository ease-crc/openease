# EASE-2020-PR2-Setting-Up-Table

<img src="/static/img/neem-overview/images/ease-2020-projection-fetch-and-place/spoon-drawer-bullet.png" alt="drawing" width="500"/>


This neem represents a PR2 setting-up a table for breakfast.  The episodes are generated in projection(simulation). This neem contains **784** episodes. This data was collected during the EASE project.

## Information

### About EASE
> EASE is an interdisciplinary research center at the University of Bremen that investigates 
> everyday activity science and engineering. 
> Its core purpose is to advance our understanding of how human-scale manipulation tasks can be mastered by robotic agents. To achieve this, EASE establishes the research area "Everyday Activity Science and Engineering" and creates a research community that conducts open research, open training, open data, and knowledge sharing. - https://ease-crc.org/

### Dataset
The PR2 was used to setup a table for breakfast.
This experiment was repeated to create 784 episodes in total.
The execution was performed in simulation.
We are utilizing simulation to enable faster learning since it allows us to generate a significant amount of data in a short period and safe environment.
The software used is available on github: [https://github.com/cram2/cram]( https://github.com/cram2/cram).
You can also read additional materials about where we are utilizing the simulated environment to improve the robots performance:

1. [Self-Specialization of General Robot Plans Based on Experience](https://ieeexplore.ieee.org/document/8763992)
   
2. [Learning Motion Parameterizations of Mobile Pick and Place Actions from Observing Humans in Virtual Environments](http://ras.papercept.net/images/temp/IROS/files/2587.pdf)
   
3. [The Robot Household Marathon Experiment](https://arxiv.org/abs/2011.09792)
   
4. [URoboSim -- An Episodic Simulation Framework for Prospective Reasoning in Robotic Agents](https://arxiv.org/abs/2012.04442)

### Acknowledgements
This work was supported  by the DFG CRC Everyday Activity Science and Engineering (EASE)(CRC #1320)and DFG Project PIPE (prj. #322037152).

## Accessing the data

Please refer to the NEEM-Hub section in [NEEM-Handbook](https://ease-crc.github.io/soma/owl/current/NEEM-Handbook.pdf) how you can download the data set.

## License
[MIT](https://choosealicense.com/licenses/mit/)
