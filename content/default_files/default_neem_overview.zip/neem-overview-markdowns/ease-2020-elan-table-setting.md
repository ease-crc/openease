# EASE-TSD

The EASE Table Setting Dataset (EASE-TSD) contains high-dimensional biosignal data(time-aligned in a "partitur" file) from participants who were given the task to set the table while be-ing recorded with a panoply of sensors under various task conditions (e.g., setting the table for adifferent number of people, varying meals and degrees of formality)(Meier et al., 2018). EASE-TSD consists of a multitude of tightly synchronized time-aligned biosignals resulting from motion capture,multi-perspective RGB-video, audio recording of speech and acoustic events, electroencephalography(EEG), electromyography (EMG), and eye tracking(Mason et al., 2018). The data is semantically an-notated on various levels of granularity and abstraction on the basis of concurrent and retrospectivethink-aloud descriptions. The annotation is done in a semi-automatic fashion blending manual annota-tions of human experts with automatic classification and recognition output.

<center><img src="/static/img/neem-overview/images/ease-2020-elan-table-setting/images_sideview.png"  width="500" height="352"></center>

## NEEM-Experience

| Modality           | Channels  | Info                   |
| ------------------ | --------- | ---------------------- |
| Third-Person-Video | 6 cameras | 720p 30fps             |
| First-Person-Video | 1 camera  | 1080p wide-amgle 30fps |
| Seech Audio        | 1         | 44kHz                  |
| Room Audio         | 1         | 44kHz                  |
| Motion Caputer     | 9 cameras | 120Hz                  |
| Eyetracking        | 1 (gaze ) |                        |
| EEG                | 16        | wet-electrode          |
| EMG (lower-arm)    | 2x8       | 600 / 1000Hz           |
| EDA                | 1         | 600Hz                  |
| Acceleration       | 2         | 600Hz                  |


# NEEM-Narrative
 - Video-based annotation
 - Transcription of think-aloud protocols
 - semmantic annotations for think-aloud protocols

## Task

Participant are ask to set the a table for a formal or informal lunch or breakfast for two or four persons.

<img src="/static/img/neem-overview/images/ease-2020-elan-table-setting/images_conditions.png"  width="500" height="120">

## References

> Celeste Mason, Moritz Meier, Florian Ahrens, Thorsten Fehr, Manfred Herrmann, Felix Putze, and Tanja Schultz. Human
> Activities Data Collection and Labeling using a Think-aloud Protocol in a Table Setting Scenario. IROS, 2018.

> Celeste Mason, Konrad Gadzicki, Moritz Meier, Florian Ahrens, Thorsten Kluss, Jaime Maldonado, Felix Putze, Thorsten
> Fehr, Christoph Zetzsche, Manfred Herrmann, Kerstin Schill, and Tanja Schultz. From Human to Robot Everyday Activity.
> In IROS 2020, Las Vegas, USA, 2020.
> 
> Moritz Meier, Celeste Mason, Robert Porzel, Felix Putze, and Tanja Schultz. Synchronized multimodal recording of a table
> setting dataset. In IROS 2018: Workshop on Latest Advances in Big Activity Data Sources for Robotics & New Challenges,
> Madrid, Spain. IROS, 2018.
> 
> Moritz Meier, Celeste Mason, Felix Putze, and Tanja Schultz. Comparative Analysis of Think-aloud Methods for Everyday
> Activities in the Context of Cognitive Robotics. In 20th Annual Conference of the International Speech Communication
> Association, volume 9, page 10, 2019a.
