# REFILLS-Shelf-Scanning-Simulation

Neems of the Kuka KMR-IIWA scanning the retail lab at uni bremen in simulation.


## Accessing the data

Please refer to the NEEM-Hub section in [NEEM-Handbook](https://ease-crc.github.io/soma/owl/current/NEEM-Handbook.pdf) how you can download the data set.

## License
[MIT](https://choosealicense.com/licenses/mit/)
