# URoboSim-Kitchen-Fetch-Place

This neem represents a PR2 peforming fetch an place actions in a kitchen environment. The episodes are generated using URoboSim. This data was collected during the EASE project.

## Information

### About EASE
> EASE is an interdisciplinary research center at the University of Bremen that investigates 
> everyday activity science and engineering. 
> Its core purpose is to advance our understanding of how human-scale manipulation tasks can be mastered by robotic agents. To achieve this, EASE establishes the research area "Everyday Activity Science and Engineering" and creates a research community that conducts open research, open training, open data, and knowledge sharing. - https://ease-crc.org/

### Dataset
The PR2 was used to setup a table for breakfast.
The execution was performed using URoboSim.
We are utilizing simulation to enable faster learning since it allows us to generate a significant amount of data in a short period and safe environment while using the perception-action loop of the 
real robot.
The software used is available on github: 
*  [https://github.com/urobosim](https://github.com/urobosim)
*  [https://github.com/cram2/cram]( https://github.com/cram2/cram)

You can also read additional materials about where we are utilizing the simulated environment to improve the robots performance:

1. [Learning Motion Parameterizations of Mobile Pick and Place Actions from Observing Humans in Virtual Environments](http://ras.papercept.net/images/temp/IROS/files/2587.pdf)
   
2. [The Robot Household Marathon Experiment](https://arxiv.org/abs/2011.09792)
   
3. [URoboSim -- An Episodic Simulation Framework for Prospective Reasoning in Robotic Agents](https://arxiv.org/abs/2012.04442)

### Acknowledgements
This work was supported  by the DFG CRC Everyday Activity Science and Engineering (EASE)(CRC #1320)and DFG Project PIPE (prj. #322037152).

## Accessing the data

Please refer to the NEEM-Hub section in [NEEM-Handbook](https://ease-crc.github.io/soma/owl/current/NEEM-Handbook.pdf) how you can download the data set.

## License
[MIT](https://choosealicense.com/licenses/mit/)
