# EASE Kitchen Clash Dataset
![Kitchen Clash](/static/img/neem-overview-images/ease-2020-kitchenclash-prepare-a-steak/oNEo6iD.png)

## Information

### About EASE
> EASE is an interdisciplinary research center at the University of Bremen that investigates 
> everyday activity science and engineering. 
> Its core purpose is to advance our understanding of how human-scale manipulation tasks can be mastered by robotic agents. To achieve this, EASE establishes the research area "Everyday Activity Science and Engineering" and creates a research community that conducts open research, open training, open data, and knowledge sharing. - https://ease-crc.org/

## Dataset
This dataset stems from the evaluation of the everyday activity human computation game Kitchen Clash ( https://link.springer.com/chapter/10.1007/978-3-030-34644-7_7 ). In total, twenty players performed three distinct tasks ("Set a table for two persons.", "Prepare a cucumber salad." and "Prepare a steak.") by performing physical manipulations and object combinations in Virtual Reality. In addition to the recorded player body, head and hand movement ( tf.json ), the sequence of symbolic actions is stored in triples.json.

### Acknowledgements
This work was supported by the DFG CRC Everyday Activity Science and Engineering (EASE)(CRC #1320).

## Accessing the data

Please refer to the NEEM-Hub section in [NEEM-Handbook](https://ease-crc.github.io/soma/owl/current/NEEM-Handbook.pdf) how you can download the data set.


## License
[MIT](https://choosealicense.com/licenses/mit/)
