# REFILLS-Shelf-Scanning

Neems of the Kuka KMR-IIWA performing scenario #1 - shelf monitoring of [REFILLS](http://www.refills-project.eu/) in the retail lab at the University of Bremen.

## Information

### About REFILLS
While online grocery stores are expanding, supermarkets continue to provide customers with the sensory experience of choosing goods while walking between display shelves. Retail and logistics companies are committed towards a shopping experience more comfortable and exciting while, at the same time, using technology to reduce costs and increase efficiency. The H2020 REFILLS Research and Innovation Action (1/1/2017—30/6/2020) will improve logistics in a supermarket thanks to mobile robotic systems in close and smart collaboration with humans, addressing the main in-store logistics processes for retail shops: in particular, robots will allow a smarter shelf refilling. Information on the supermarket articles is exploited to create powerful knowledge bases, used by the robots to identify shelves, recognize missing or misplaced articles, handle them and navigate the shop. Reasoning allows robots to cope with changing task requirements and contexts, and perception-guided reactive control makes them robust to execution errors and uncertainty. A modular approach is adopted for the design of cost-efficient robotic units. A final demonstration will take place at a real retail store. In sum, REFILLS is committed to generating wide impact in the retail market domain and beyond through the development of efficient logistics solutions for professional use.

### Dataset
The Kuka KMR-IIWA was used to create a semantic store map of the retail lab at the University Bremen. 
The robot is equipped with 2 cameras, one high resolution rgb and one rgbd camera.
The episodes contain the poses of all 19 shelf frames.
For four of these shelves, the shelf monitoring was executed, where shelf layers, product labels, separators and number of products in facings were detected.
This experiment was repeated to create three episodes in total.
The software used is available on github: [https://github.com/refills-project](https://github.com/refills-project)

### Acknowledgements
This work was supported by the European Commission within H2020 REFILLS Project 731590,
by the DFG CRC Everyday Activity Science and Engineering (EASE)(CRC #1320),
and by BMWi project Knowledge4Retail.

## Accessing the data

Please refer to the NEEM-Hub section in [NEEM-Handbook](https://ease-crc.github.io/soma/owl/current/NEEM-Handbook.pdf) how you can download the data set.

## License
[MIT](https://choosealicense.com/licenses/mit/)
